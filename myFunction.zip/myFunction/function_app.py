import logging
import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import azure.functions as func
import json
import pymongo
from pymongo import MongoClient
import os
 
# Download necessary NLTK datasets if not already downloaded
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
 
try:
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt_tab')
 
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')
 
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')
 
# Initialize lemmatizer and stopwords
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))
 
# MongoDB connection details (use your actual connection string)
MONGO_URI = "mongodb://beyondhumancosmosmongodb:8igjEd0wSlV0jFCiAIcDDoQQcSu0xnGXLvP8nGqOM1ttlLH4lyucqnu88vL6lzhoWyK7VG6GSNfKACDb82ADfw==@beyondhumancosmosmongodb.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@beyondhumancosmosmongodb@"  # Store this in the environment variable or hard-code for testing
DATABASE_NAME = "BeyondHuman_CosmosMongodb"
COLLECTION_NAME = "cosmosmongodbcollection"
 
# Initialize MongoDB client
client = MongoClient(MONGO_URI)
db = client[DATABASE_NAME]
collection = db[COLLECTION_NAME]
 
# Define function to lemmatize a sentence
def lemmatize_sentence(sentence: str):
    """Lemmatizes words from a sentence and removes stopwords."""
    words = word_tokenize(sentence)
    return [lemmatizer.lemmatize(word.lower()) for word in words if word.lower() not in stop_words and word.isalpha()]
 
# Create a Function App instance
app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)
 
# Define route for lemmatize function
@app.route(route="http_trigger")
def http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Processing a request to lemmatize a sentence.')
 
    # Get the sentence from query parameters
    sentence = req.params.get('sentence')
 
    # If the sentence is not in query parameters, check the request body
    if not sentence:
        try:
            req_body = req.get_json()
            sentence = req_body.get('sentence')
        except ValueError:
            pass
 
    # If no sentence is provided, return an error message
    if not sentence:
        return func.HttpResponse(
            '{"error": "Please provide a sentence in the query string or in the request body."}',
            mimetype="application/json",
            status_code=400
        )
 
    # Lemmatize the sentence
    root_words = lemmatize_sentence(sentence)
 
    # Join the root words into a single string separated by hyphens
    root_words_str = '-'.join(root_words)
    existing_document = collection.find_one({"root_words": root_words_str})
 
    if existing_document:
        # If document exists, return the value field (assuming the value field is 'value')
        value_field = existing_document.get('value', 'No value found')
        return func.HttpResponse(
            f'{{"root_words": "{root_words_str}", "found_in_db": true, "value": "{value_field}"}}',
            mimetype="application/json",
            status_code=200
        )
    else:
        # If document does not exist, insert a new document
        try:
            document = {
                "sentence": sentence,
                "root_words": root_words_str,
                "value": "Some_value_to_store"
            }
            collection.insert_one(document)  # Insert the document into MongoDB
            logging.info(f"Document inserted: {document}")
        except Exception as e:
            logging.error(f"Error inserting document to MongoDB: {str(e)}")
   
            return func.HttpResponse(
                f'{{"root_words": "{root_words_str}", "found_in_db": false}}',
                mimetype="application/json",
                status_code=200
            )
        except Exception as e:
            logging.error(f"Error inserting document to MongoDB: {str(e)}")
            return func.HttpResponse(
                '{"error": "Error inserting document to MongoDB."}',
                mimetype="application/json",
                status_code=500
            )