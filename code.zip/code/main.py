import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
 
# Download necessary NLTK datasets (run this once)
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('stopwords')
 
def get_root_words(sentence):
    # Initialize the lemmatizer and stopwords
    lemmatizer = WordNetLemmatizer()
    stop_words = set(stopwords.words('english'))
    # Tokenize the sentence
    words = word_tokenize(sentence)
    # Lemmatize each word, remove stopwords, and keep only root words
    root_words = [lemmatizer.lemmatize(word.lower()) for word in words if word.lower() not in stop_words and word.isalpha()]
    return root_words
 
# Example usage:
sentence = input("Enter a sentence: ")
root_words = get_root_words(sentence)
print("Root words:", root_words)